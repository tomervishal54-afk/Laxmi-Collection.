# Laxmi Collection Website

This is your Next.js website for Laxmi Collection.

## 🚀 How to Run
1. Install dependencies:
   ```bash
   npm install
   ```

2. Run locally:
   ```bash
   npm run dev
   ```
   Open http://localhost:3000

3. Deploy on Vercel:
   - Push this project to GitHub
   - Go to [Vercel](https://vercel.com)
   - Import the repository
   - Click Deploy
