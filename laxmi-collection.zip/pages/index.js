import LaxmiCollection from "../components/LaxmiCollection";

export default function Home() {
  return <LaxmiCollection />;
}
