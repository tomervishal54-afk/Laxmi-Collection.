import { useMemo, useState, useEffect } from "react";
import { motion } from "framer-motion";

// ----- UTILITIES -----
const currency = (n) => `₹${n.toLocaleString("en-IN")}`;
const uid = () => Math.random().toString(36).slice(2, 10).toUpperCase();

// ----- SEED DATA -----
const seedProducts = [
  { id: "s1", name: "Designer Suit – Maroon", price: 2499, image: "/suit1.jpg", sizes: ["S","M","L","XL"], category: "Designer", fabric: "Georgette" },
  { id: "s2", name: "Designer Suit – Emerald", price: 3199, image: "/suit2.jpg", sizes: ["S","M","L","XL"], category: "Designer", fabric: "Silk Blend" },
  { id: "s3", name: "Party Wear Suit – Gold", price: 4299, image: "/suit3.jpg", sizes: ["M","L","XL"], category: "Party Wear", fabric: "Chiffon" },
  { id: "s4", name: "Daily Wear – Floral Blue", price: 1599, image: "/suit4.jpg", sizes: ["S","M","L"], category: "Daily", fabric: "Cotton" },
];

export default function LaxmiCollection() {
  const [page, setPage] = useState("home");
  const [products] = useState(seedProducts);
  const [cart, setCart] = useState([]);

  const addToCart = (product, size="M") => {
    setCart(prev => [...prev, { ...product, size, qty: 1 }]);
  };

  const subtotal = cart.reduce((s,i)=> s + i.price * i.qty, 0);
  const shipping = subtotal > 4999 || subtotal===0 ? 0 : 99;
  const total = subtotal + shipping;

  const logoSrc = "/logo.png";

  return (
    <div className="bg-purple-900 min-h-screen text-yellow-400">
      {/* HEADER */}
      <header className="text-center py-6">
        <img src={logoSrc} alt="Laxmi Collection" className="mx-auto w-24 mb-4 rounded-full ring-2 ring-yellow-400" />
        <h1 className="text-4xl font-bold">LAXMI COLLECTION</h1>
        <p className="text-lg">Best Quality Suits</p>
        <nav className="mt-4 flex justify-center gap-4">
          <button onClick={()=>setPage("home")}>Home</button>
          <button onClick={()=>setPage("shop")}>Collection</button>
          <button onClick={()=>setPage("cart")}>Cart ({cart.length})</button>
        </nav>
      </header>

      {/* HOME */}
      {page==="home" && (
        <section className="max-w-4xl mx-auto px-4 pb-12">
          <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} className="bg-yellow-100 text-purple-900 rounded-2xl p-8 md:p-12 shadow-xl grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-3xl font-bold mb-3">Grace. Quality. Comfort.</h2>
              <p className="mb-6">Explore our curated collection of designer, party and daily-wear suits. Crafted with premium fabrics and tailored fits.</p>
              <button className="bg-purple-900 text-yellow-100 px-4 py-2 rounded" onClick={()=>setPage("shop")}>Shop Now</button>
            </div>
            <img src="/suit1.jpg" alt="Sample" className="w-full rounded-2xl object-cover" />
          </motion.div>
        </section>
      )}

      {/* SHOP */}
      {page==="shop" && (
        <section className="max-w-6xl mx-auto px-4 pb-16 grid sm:grid-cols-2 md:grid-cols-3 gap-6">
          {products.map(p => (
            <div key={p.id} className="bg-yellow-100 text-purple-900 rounded-2xl p-4">
              <img src={p.image} alt={p.name} className="w-full h-56 object-cover rounded-xl" />
              <h3 className="text-lg font-semibold mt-2">{p.name}</h3>
              <p>{currency(p.price)}</p>
              <button className="mt-2 w-full bg-purple-900 text-yellow-100 px-3 py-2 rounded" onClick={()=>addToCart(p)}>Add to Cart</button>
            </div>
          ))}
        </section>
      )}

      {/* CART */}
      {page==="cart" && (
        <section className="max-w-3xl mx-auto px-4 pb-16">
          <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
          {cart.length===0 ? <p>No items in cart</p> : (
            <div className="space-y-2">
              {cart.map((item, i)=>(
                <div key={i} className="bg-yellow-100 text-purple-900 p-3 rounded-xl flex justify-between">
                  <span>{item.name} ({item.size})</span>
                  <span>{currency(item.price)}</span>
                </div>
              ))}
              <div className="mt-4 font-semibold">Subtotal: {currency(subtotal)}</div>
              <div>Shipping: {shipping===0?"FREE":currency(shipping)}</div>
              <div className="text-xl font-bold">Total: {currency(total)}</div>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
